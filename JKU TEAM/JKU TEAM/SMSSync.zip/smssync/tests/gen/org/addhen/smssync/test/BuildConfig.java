/** Automatically generated file. DO NOT MODIFY */
package org.addhen.smssync.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}